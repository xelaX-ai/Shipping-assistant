import { ExpoConfig } from "expo/config";

const config: ExpoConfig = {
  name: "Shipping Assistant",
  slug: "shipping-assistant",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/icon.png",
  userInterfaceStyle: "light",
  splash: {
    backgroundColor: "#0F172A",
  },
  android: {
    adaptiveIcon: {
      backgroundColor: "#0F172A",
    },
    package: "com.yourcompany.shippingassistant",
  },
  plugins: ["expo-router"],
  scheme: "shipping-assistant",
  extra: {
    // Вставьте ваш Gemini API ключ здесь
    // Получить бесплатно: https://aistudio.google.com/app/apikey
    GEMINI_API_KEY: process.env.GEMINI_API_KEY || "YOUR_GEMINI_API_KEY_HERE",
  },
};

export default config;
