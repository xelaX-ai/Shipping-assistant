import Constants from "expo-constants";
import { buildManualContext, SYSTEM_PROMPT } from "../data/manuals";

const API_KEY = Constants.expoConfig?.extra?.GEMINI_API_KEY;
const API_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export async function askGemini(
  question: string,
  history: Message[]
): Promise<string> {
  if (!API_KEY || API_KEY === "YOUR_GEMINI_API_KEY_HERE") {
    return "⚠️ API ключ не налаштовано. Відкрийте файл app.config.ts і вставте ваш Gemini API ключ.\n\nОтримати безкоштовно: https://aistudio.google.com/app/apikey";
  }

  const manualContext = buildManualContext();

  const fullPrompt = `${SYSTEM_PROMPT}

МАНУАЛИ:
${manualContext}

Питання: ${question}`;

  try {
    const response = await fetch(`${API_URL}?key=${API_KEY}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [{ text: fullPrompt }],
          },
        ],
        generationConfig: {
          temperature: 0.1,
          maxOutputTokens: 1024,
          topP: 0.8,
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_HARASSMENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
        ],
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error("Gemini API error:", error);
      return `Помилка API: ${error.error?.message || "Невідома помилка"}`;
    }

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!text) {
      return "Не вдалося отримати відповідь. Спробуйте ще раз.";
    }

    return text;
  } catch (error) {
    console.error("Network error:", error);
    return "Помилка мережі. Перевірте підключення до інтернету.";
  }
}
